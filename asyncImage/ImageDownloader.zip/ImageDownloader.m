
//ImageDownloader
#import "ImageDownloader.h"
#import <objc/message.h>
#import <QuartzCore/QuartzCore.h>


NSString *const ImageLoadDidFinish = @"ImageLoadDidFinish";
NSString *const ImageLoadDidFail = @"ImageLoadDidFail";
NSString *const ImageTargetReleased = @"ImageTargetReleased";

NSString *const ImageImageKey = @"image";
NSString *const ImageURLKey = @"URL";
NSString *const ImageCacheKey = @"cache";
NSString *const ImageErrorKey = @"error";


@interface ImageCache ()

@property (nonatomic, strong) NSCache *cache;

@end


@implementation ImageCache

@synthesize cache;
@synthesize useImageNamed;

+ (ImageCache *)sharedCache
{
    static ImageCache *sharedInstance = nil;
    if (sharedInstance == nil)
    {
        sharedInstance = [[self alloc] init];
    }
    return sharedInstance;
}

- (id)init
{
    if ((self = [super init]))
    {
		useImageNamed = YES;
        cache = [[NSCache alloc] init];
    }
    return self;
}

- (void)setCountLimit:(NSUInteger)countLimit
{
    cache.countLimit = countLimit;
}

- (NSUInteger)countLimit
{
    return cache.countLimit;
}

- (UIImage *)imageForURL:(NSURL *)URL
{
	if (useImageNamed && [URL isFileURL])
	{
		NSString *path = [URL path];
		NSString *imageName = [path lastPathComponent];
		NSString *directory = [path stringByDeletingLastPathComponent];
		if ([[[NSBundle mainBundle] resourcePath] isEqualToString:directory])
		{
			return [UIImage imageNamed:imageName];
		}
	}
    return [cache objectForKey:URL];
}

- (void)setImage:(UIImage *)image forURL:(NSURL *)URL
{
    if (useImageNamed && [URL isFileURL])
    {
        NSString *path = [URL path];
        NSString *directory = [path stringByDeletingLastPathComponent];
        if ([[[NSBundle mainBundle] resourcePath] isEqualToString:directory])
        {
            //do not store in cache
            return;
        }
    }
    [cache setObject:image forKey:URL];
}

- (void)removeImageForURL:(NSURL *)URL
{
    [cache removeObjectForKey:URL];
}

- (void)clearCache
{
    //remove objects that aren't in use
    [cache removeAllObjects];
}

- (void)dealloc
{
    AH_RELEASE(cache);
    AH_SUPER_DEALLOC;
}

@end


@interface ImageConnection : NSObject

@property (nonatomic, strong) NSURLConnection *connection;
@property (nonatomic, strong) NSMutableData *data;
@property (nonatomic, strong) NSURL *URL;
@property (nonatomic, strong) ImageCache *cache;
@property (nonatomic, strong) id target;
@property (nonatomic, assign) SEL success;
@property (nonatomic, assign) SEL failure;
@property (nonatomic, assign) BOOL decompressImage;
@property (nonatomic, readonly, getter = isLoading) BOOL loading;
@property (nonatomic, readonly) BOOL cancelled;

+ (ImageConnection *)connectionWithURL:(NSURL *)URL
                                      cache:(ImageCache *)cache
									 target:(id)target
									success:(SEL)success
									failure:(SEL)failure
							decompressImage:(BOOL)decompressImage;

- (ImageConnection *)initWithURL:(NSURL *)URL
                                cache:(ImageCache *)cache
							   target:(id)target
							  success:(SEL)success
							  failure:(SEL)failure
					  decompressImage:(BOOL)decompressImage;

- (void)start;
- (void)cancel;
- (BOOL)isInCache;

@end


@implementation ImageConnection

@synthesize connection;
@synthesize data;
@synthesize URL;
@synthesize cache;
@synthesize target;
@synthesize success;
@synthesize failure;
@synthesize decompressImage;
@synthesize loading;
@synthesize cancelled;


+ (ImageConnection *)connectionWithURL:(NSURL *)URL
                                      cache:(ImageCache *)_cache
									 target:(id)target
									success:(SEL)_success
									failure:(SEL)_failure
							decompressImage:(BOOL)_decompressImage
{
    return AH_AUTORELEASE([[self alloc] initWithURL:URL
                                              cache:_cache
                                             target:target
                                            success:_success
                                            failure:_failure
                                    decompressImage:_decompressImage]);
}

- (ImageConnection *)initWithURL:(NSURL *)_URL
                                cache:(ImageCache *)_cache
							   target:(id)_target
							  success:(SEL)_success
							  failure:(SEL)_failure
					  decompressImage:(BOOL)_decompressImage
{
    if ((self = [self init]))
    {
        self.URL = _URL;
        self.cache = _cache;
        self.target = _target;
        self.success = _success;
        self.failure = _failure;
		self.decompressImage = _decompressImage;
    }
    return self;
}

- (BOOL)isInCache
{
    return [cache imageForURL:URL] != nil;
}

- (void)loadFailedWithError:(NSError *)error
{
	loading = NO;
	cancelled = NO;
    [[NSNotificationCenter defaultCenter] postNotificationName:ImageLoadDidFail
                                                        object:target
                                                      userInfo:[NSDictionary dictionaryWithObjectsAndKeys:
                                                                URL, ImageURLKey,
                                                                error, ImageErrorKey,
                                                                nil]];
}

- (void)cacheImage:(UIImage *)image
{
	if (!cancelled)
	{
        if (image)
        {
            [cache setImage:image forURL:URL];
        }
        
		NSMutableDictionary *userInfo = [NSMutableDictionary dictionaryWithObjectsAndKeys:
										 image, ImageImageKey,
										 URL, ImageURLKey,
										 nil];
		if (cache)
		{
			[userInfo setObject:cache forKey:ImageCacheKey];
		}
		
		loading = NO;
		[[NSNotificationCenter defaultCenter] postNotificationName:ImageLoadDidFinish
															object:target
														  userInfo:AH_AUTORELEASE([userInfo copy])];
	}
	else
	{
		loading = NO;
		cancelled = NO;
	}
}

- (void)decompressImageInBackground:(UIImage *)image
{
	@synchronized ([self class])
	{
		if (!cancelled && decompressImage)
		{
			//force image decompression
			UIGraphicsBeginImageContext(CGSizeMake(1, 1));
			[image drawAtPoint:CGPointZero];
			UIGraphicsEndImageContext();
		}

		//add to cache (may be cached already but it doesn't matter)
		[self performSelectorOnMainThread:@selector(cacheImage:)
							   withObject:image
							waitUntilDone:YES];
	}
}

- (void)processDataInBackground:(NSData *)_data
{
	@synchronized ([self class])
	{	
		if (!cancelled)
		{
			UIImage *image = [[UIImage alloc] initWithData:_data];
			if (image)
			{
				[self decompressImageInBackground:image];
                AH_RELEASE(image);
			}
			else
			{
                @autoreleasepool
                {
                    NSError *error = [NSError errorWithDomain:@"ImageLoader" code:0 userInfo:[NSDictionary dictionaryWithObject:@"Invalid image data" forKey:NSLocalizedDescriptionKey]];
                    [self performSelectorOnMainThread:@selector(loadFailedWithError:) withObject:error waitUntilDone:YES];
				}
			}
		}
		else
		{
			//clean up
			[self performSelectorOnMainThread:@selector(cacheImage:)
								   withObject:nil
								waitUntilDone:YES];
		}
	}
}

- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response
{
    self.data = [NSMutableData data];
}

- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)_data
{
    //check for cached image
	UIImage *image = [cache imageForURL:URL];
    if (image)
    {
        [self cancel];
        [self performSelectorInBackground:@selector(decompressImageInBackground:) withObject:image];
        return;
    }
    
    //add data
    [data appendData:_data];
}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection
{
    [self performSelectorInBackground:@selector(processDataInBackground:) withObject:data];
    self.connection = nil;
    self.data = nil;
}

- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error
{
    self.connection = nil;
    self.data = nil;
    [self loadFailedWithError:error];
}

- (void)start
{
    if (loading && !cancelled)
    {
        return;
    }
	
	//begin loading
	loading = YES;
	cancelled = NO;
    
    //check for nil URL
    if (URL == nil)
    {
        [self cacheImage:nil];
        return;
    }
    
    //check for cached image
	UIImage *image = [cache imageForURL:URL];
    if (image)
    {
        [self performSelectorInBackground:@selector(decompressImageInBackground:) withObject:image];
        return;
    }
    
    //begin load
    NSURLRequest *request = [NSURLRequest requestWithURL:URL
                                             cachePolicy:NSURLCacheStorageNotAllowed
                                         timeoutInterval:[ImageLoader sharedLoader].loadingTimeout];
    
    connection = [[NSURLConnection alloc] initWithRequest:request delegate:self startImmediately:NO];
    [connection scheduleInRunLoop:[NSRunLoop mainRunLoop] forMode:NSRunLoopCommonModes];
    [connection start];
}

- (void)cancel
{
	cancelled = YES;
    [connection cancel];
    self.connection = nil;
    self.data = nil;
}

- (void)dealloc
{
    AH_RELEASE(connection);
    AH_RELEASE(data);
    AH_RELEASE(URL);
    AH_RELEASE(target);
    AH_SUPER_DEALLOC;
}

@end


@interface ImageLoader ()

@property (nonatomic, strong) NSMutableArray *connections;

@end


@implementation ImageLoader

@synthesize cache;
@synthesize connections;
@synthesize concurrentLoads;
@synthesize loadingTimeout;
@synthesize decompressImages;

+ (ImageLoader *)sharedLoader
{
	static ImageLoader *sharedInstance = nil;
	if (sharedInstance == nil)
	{
		sharedInstance = [[self alloc] init];
	}
	return sharedInstance;
}

- (ImageLoader *)init
{
	if ((self = [super init]))
	{
        cache = AH_RETAIN([ImageCache sharedCache]);
        concurrentLoads = 2;
        loadingTimeout = 60;
		decompressImages = NO;
		connections = [[NSMutableArray alloc] init];
        [[NSNotificationCenter defaultCenter] addObserver:self
												 selector:@selector(imageLoaded:)
													 name:ImageLoadDidFinish
												   object:nil];
		[[NSNotificationCenter defaultCenter] addObserver:self
												 selector:@selector(imageFailed:)
													 name:ImageLoadDidFail
												   object:nil];
        [[NSNotificationCenter defaultCenter] addObserver:self
												 selector:@selector(targetReleased:)
													 name:ImageTargetReleased
												   object:nil];
	}
	return self;
}

- (void)updateQueue
{
    //start connections
    NSInteger count = 0;
    for (ImageConnection *connection in connections)
    {
        if (![connection isLoading])
        {
            if ([connection isInCache])
            {
                [connection start];
            }
            else if (count < concurrentLoads)
            {
                count ++;
                [connection start];
            }
        }
    }
}

- (void)imageLoaded:(NSNotification *)notification
{  
    //complete connections for URL
    NSURL *URL = [notification.userInfo objectForKey:ImageURLKey];
    for (int i = [connections count] - 1; i >= 0; i--)
    {
        ImageConnection *connection = [connections objectAtIndex:i];
        if (connection.URL == URL || [connection.URL isEqual:URL])
        {
            //cancel earlier connections for same target/action
            for (int j = i - 1; j >= 0; j--)
            {
                ImageConnection *earlier = [connections objectAtIndex:j];
                if (earlier.target == connection.target &&
                    earlier.success == connection.success)
                {
                    [earlier cancel];
                    [connections removeObjectAtIndex:j];
                    i--;
                }
            }
            
            //cancel connection (in case it's a duplicate)
            [connection cancel];
            
            //perform action
			UIImage *image = [notification.userInfo objectForKey:ImageImageKey];
            objc_msgSend(connection.target, connection.success, image, connection.URL);

            //remove from queue
            [connections removeObjectAtIndex:i];
        }
    }
    
    //update the queue
    [self updateQueue];
}

- (void)imageFailed:(NSNotification *)notification
{
    //remove connections for URL
    NSURL *URL = [notification.userInfo objectForKey:ImageURLKey];
    for (int i = [connections count] - 1; i >= 0; i--)
    {
        ImageConnection *connection = [connections objectAtIndex:i];
        if ([connection.URL isEqual:URL])
        {
            //cancel connection (in case it's a duplicate)
            [connection cancel];
            
            //perform failure action
            if (connection.failure)
            {
                NSError *error = [notification.userInfo objectForKey:ImageErrorKey];
                objc_msgSend(connection.target, connection.failure, error, URL);
            }
            
            //remove from queue
            [connections removeObjectAtIndex:i];
        }
    }
    
    //update the queue
    [self updateQueue];
}

- (void)targetReleased:(NSNotification *)notification
{
    //remove connections for URL
    id target = [notification object];
    for (int i = [connections count] - 1; i >= 0; i--)
    {
        ImageConnection *connection = [connections objectAtIndex:i];
        if (connection.target == target)
        {
            //cancel connection
            [connection cancel];
            [connections removeObjectAtIndex:i];
        }
    }
    
    //update the queue
    [self updateQueue];
}

- (void)loadImageWithURL:(NSURL *)URL target:(id)target success:(SEL)success failure:(SEL)failure
{
    //create new connection
    [connections addObject:[ImageConnection connectionWithURL:URL
                                                             cache:cache
															target:target
														   success:success
														   failure:failure
												   decompressImage:decompressImages]];
    [self updateQueue];
}

- (void)loadImageWithURL:(NSURL *)URL target:(id)target action:(SEL)action
{
    [self loadImageWithURL:URL target:target success:action failure:NULL];
}

- (void)loadImageWithURL:(NSURL *)URL
{
    [self loadImageWithURL:URL target:nil success:NULL failure:NULL];
}

- (void)cancelLoadingURL:(NSURL *)URL target:(id)target action:(SEL)action
{
    for (int i = [connections count] - 1; i >= 0; i--)
    {
        ImageConnection *connection = [connections objectAtIndex:i];
        if ([connection.URL isEqual:URL] && connection.target == target && connection.success == action)
        {
            [connection cancel];
            [connections removeObjectAtIndex:i];
        }
    }
}

- (void)cancelLoadingURL:(NSURL *)URL target:(id)target
{
    for (int i = [connections count] - 1; i >= 0; i--)
    {
        ImageConnection *connection = [connections objectAtIndex:i];
        if ([connection.URL isEqual:URL] && connection.target == target)
        {
            [connection cancel];
            [connections removeObjectAtIndex:i];
        }
    }
}

- (void)cancelLoadingURL:(NSURL *)URL
{
    for (int i = [connections count] - 1; i >= 0; i--)
    {
        ImageConnection *connection = [connections objectAtIndex:i];
        if ([connection.URL isEqual:URL])
        {
            [connection cancel];
            [connections removeObjectAtIndex:i];
        }
    }
}

- (NSURL *)URLForTarget:(id)target action:(SEL)action
{
    //return the most recent image URL assigned to the target
    //this is not neccesarily the next image that will be assigned
    for (int i = [connections count] - 1; i >= 0; i--)
    {
        ImageConnection *connection = [connections objectAtIndex:i];
        if (connection.target == target && connection.success == action)
        {
            return AH_AUTORELEASE(AH_RETAIN(connection.URL));
        }
    }
    return nil;
}

- (void)dealloc
{
	[[NSNotificationCenter defaultCenter] removeObserver:self];
    AH_RELEASE(cache);
    AH_RELEASE(connections);
    AH_SUPER_DEALLOC;
}

@end


@implementation UIImageView(ImageDownloader)

- (void)setImageURL:(NSURL *)imageURL
{
	[[ImageLoader sharedLoader] loadImageWithURL:imageURL target:self action:@selector(setImage:)];
}

- (NSURL *)imageURL
{
	return [[ImageLoader sharedLoader] URLForTarget:self action:@selector(setImage:)];
}

@end


@interface ImageDownloader ()

@property (nonatomic, strong) UIActivityIndicatorView *activityView;

@end


@implementation ImageDownloader


@synthesize showActivityIndicator;
@synthesize activityIndicatorStyle;
@synthesize crossfadeImages;
@synthesize crossfadeDuration;
@synthesize activityView;

- (void)setUp
{
	showActivityIndicator = (self.image == nil);
	activityIndicatorStyle = UIActivityIndicatorViewStyleGray;
    crossfadeImages = YES;
	crossfadeDuration = 0.4;
}

- (id)initWithFrame:(CGRect)frame
{
    if ((self = [super initWithFrame:frame]))
    {
        [self setUp];
    }
    return self;
}

- (id)initWithCoder:(NSCoder *)aDecoder
{
    if ((self = [super initWithCoder:aDecoder]))
    {
        [self setUp];
    }
    return self;
}

- (void)setImageURL:(NSURL *)imageURL
{
    super.imageURL = imageURL;
    if (showActivityIndicator && !self.image)
    {
        if (activityView == nil)
        {
            activityView = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:activityIndicatorStyle];
            activityView.hidesWhenStopped = YES;
            activityView.center = CGPointMake(self.bounds.size.width / 2.0f, self.bounds.size.width / 2.0f);
            activityView.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleTopMargin | UIViewAutoresizingFlexibleRightMargin | UIViewAutoresizingFlexibleBottomMargin;
            [self addSubview:activityView];
        }
        [activityView startAnimating];
    }
}

- (void)setActivityIndicatorStyle:(UIActivityIndicatorViewStyle)style
{
	activityIndicatorStyle = style;
	[activityView removeFromSuperview];
	self.activityView = nil;
}

- (void)setImage:(UIImage *)image
{
    if (crossfadeImages)
    {
        CATransition *animation = [CATransition animation];
        animation.type = kCATransitionFade;
        animation.duration = crossfadeDuration;
        [self.layer addAnimation:animation forKey:nil];
    }
    super.image = image;
    [activityView stopAnimating];
}

- (void)dealloc
{
    [[ImageLoader sharedLoader] cancelLoadingURL:self.imageURL target:self];
	AH_RELEASE(activityView);
    AH_SUPER_DEALLOC;
}

@end
